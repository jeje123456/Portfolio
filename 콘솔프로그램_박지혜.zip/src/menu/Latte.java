package menu;

public class Latte extends DrinkMenu{

	public Latte(String name, int price) {
		super(name, price);
	}
	

}
