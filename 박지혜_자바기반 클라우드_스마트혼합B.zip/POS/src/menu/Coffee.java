package menu;

public class Coffee extends DrinkMenu{

	public Coffee(String name, int price) {
		super(name, price);
	}
}
